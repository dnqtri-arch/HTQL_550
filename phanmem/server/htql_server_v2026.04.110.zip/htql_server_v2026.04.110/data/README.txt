﻿ThÆ° má»¥c dá»¯ liá»‡u JSON (á»©ng dá»¥ng táº¡o khi cháº¡y). GÃ³i build loáº¡i trá»« file demo .json.
